using System.Collections;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SlotScript : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler, IBeginDragHandler, IDragHandler
{
    BackPackController backpackController;
    public InventoryStalker inventoryStalker;
    public BackpackIconScript backpackIcon;

    public Image slot_image;
    public TextMeshProUGUI slot_amount;
    public Item slot_item;

    public int slot_index;

    public float longPressThreshold = 0.3f; // 0.1f ������� ���� ��� ��������

    private bool longPressHandled = false;
    private bool isPointerDown = false;
    private bool isDragging = false;

    private Coroutine longPressCoroutine;

    void Start()
    {
        backpackController = GameObject.Find("BackpackPanel")?.GetComponent<BackPackController>();
        //inventoryStalker = GameObject.Find("Inventory").GetComponent<InventoryStalker>();
        inventoryStalker = gameObject.GetComponentInParent<InventoryStalker>();

        EmptySlot();
    }

    public void EmptySlot()
    {
        backpackIcon = null;
        slot_item = null;
        slot_image.sprite = null;
        slot_amount.text = string.Empty;
    }

    public void UpdateSlotItem(Item item, BackpackIconScript backpackIconScript)
    {
        backpackIcon = backpackIconScript;
        slot_item = item;
        UpdateSlot();
    }

    public void UpdateSlot()
    {
        if (slot_item == null || slot_item.amount <= 0)
        {
            EmptySlot();
            return;
        }

        slot_amount.text = slot_item.amount.ToString();
        slot_image.sprite = slot_item.sprite;
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        Debug.Log("SLOT MOUSE DOWN");
        isPointerDown = true;
        isDragging = false;
        longPressHandled = false;

        if (backpackController == null) backpackController = GameObject.Find("BackpackPanel")?.GetComponent<BackPackController>();
        if (slot_item == null) return;

        if (backpackController.dict_id_to_item.ContainsKey(slot_item.id))
        {
            inventoryStalker.ChangeMouse(backpackController.dict_id_to_item[slot_item.id]);
            longPressCoroutine = StartCoroutine(LongPressRoutine());
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        Debug.Log("SLOT MOUSE UP");

        isPointerDown = false;

        if (longPressCoroutine != null)
        {
            StopCoroutine(longPressCoroutine);
            longPressCoroutine = null;
        }

        // ���� �� ���� ������� ������� � �� ���� �������������� � ������� ������
        if (!longPressHandled && !isDragging)
        {
            ItemOnClick();
        }

        // ���� ��� drag
        if (longPressHandled || isDragging)
        {
            GameObject current_GO = eventData.pointerCurrentRaycast.gameObject;
            Debug.Log($"mouse on {current_GO}");
            if (current_GO != null)
            {
                Debug.Log($"{current_GO.name} {current_GO.tag}");
                if (current_GO.tag == "BackpackUI")
                {
                    inventoryStalker.EmptySlotItem(slot_index);
                }
                else
                {
                    SlotScript newSlotScript = current_GO.GetComponent<SlotScript>();
                    if (newSlotScript != null)
                    {
                        int new_slot_index = newSlotScript.slot_index;
                        inventoryStalker.UpdateSlotItem(new_slot_index, backpackController.dict_id_to_item[slot_item.id], backpackIcon);
                    }
                }
            }
        }

        if (inventoryStalker != null && inventoryStalker.mouse_stalker != null)
        {
            inventoryStalker.mouse_stalker.MakeDefault();
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // ���� �������� � ������ � ����� �������� "������ �������", ���� ����
        if (isPointerDown && !longPressHandled)
        {
            if (longPressCoroutine != null)
            {
                StopCoroutine(longPressCoroutine);
                longPressCoroutine = null;
            }
        }
    }

    private IEnumerator LongPressRoutine()
    {
        yield return new WaitForSecondsRealtime(longPressThreshold);

        longPressHandled = true;
        longPressCoroutine = null;

        StartDrag();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        // ���� ������ �������� drag �� ������ �� long press, ����� �������� ��� ���
        isDragging = true;
    }

    public void OnDrag(PointerEventData eventData)
    {
        // ��� ����� ��������� ������� "��������" ����, ���� �����
    }

    private void ItemOnClick()
    {
        if (backpackController == null) backpackController = GameObject.Find("BackpackPanel")?.GetComponent<BackPackController>();
        if (slot_item == null) return;

        backpackController.current_selected_backpackIcon = backpackIcon;
        backpackController.UpdateShowerPanel(slot_item.id);
    }

    private void StartDrag()
    {
        isDragging = true;
        // inventory_stalker.ChangeMouse(backpackController.dict_id_to_item[id]);
    }
}
