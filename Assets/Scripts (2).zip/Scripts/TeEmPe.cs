using UnityEngine;

public abstract class TeEmPe : MonoBehaviour
{
    [SerializeField]
    protected bool isDestroyOnEnter;
    [SerializeField]
    protected float dmg;

    
}
