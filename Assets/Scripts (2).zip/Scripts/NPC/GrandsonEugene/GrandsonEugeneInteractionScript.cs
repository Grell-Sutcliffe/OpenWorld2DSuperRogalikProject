﻿using UnityEngine;

public class GrandsonEugeneInteractionScript : InteractionController
{
    protected override void Interact()
    {
        mainController.InteractGrandsonEugene();
    }
}
