﻿using UnityEngine;

public class DedusInteractionScript : InteractionController
{
    protected override void Interact()
    {
        mainController.InteractDedus();
    }
}
