using UnityEngine;

public interface IDamagable 
{
    void TakeDamage(Damage amg);

}

