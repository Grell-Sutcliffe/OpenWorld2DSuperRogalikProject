using UnityEngine;

public enum ElementType
{
    None = 0,
    Cryo = 1,
    Pyro = 2,
    Electro = 3,
    Anemo = 4,
    Physical = 5,
}