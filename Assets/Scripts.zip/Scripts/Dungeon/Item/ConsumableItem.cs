using System.Xml.Linq;
using UnityEngine;

public class ConsumableItem : Item
{
    public int amount = 1;

    public ConsumableItem(int id_, string name_, string description_, Sprite sprite_) 
    {
        id = id_;
        name = name_;
        description = description_;
        count = 0;
        sprite = sprite_;
    }

    public ConsumableItem(int id_, string name_, string description_, Sprite sprite_, int count_) 
    {
        id = id_;
        name = name_;
        description = description_;
        count = count_;
        sprite = sprite_;
    }

    public ConsumableItem(int id_, string name_, string description_, Sprite sprite_, string type_, int count_) 
    {
        id = id_;
        name = name_;
        description = description_;
        count = count_;
        type = type_;
        sprite = sprite_;
    }

    public ConsumableItem(int id_, string name_, string description_, Sprite sprite_, string type_, int stars_, int count_) 
    {
        id = id_;
        name = name_;
        description = description_;
        count = count_;
        type = type_;
        stars = stars_;
        sprite = sprite_;
    }

    public ConsumableItem(string name_, string description_, Sprite sprite_) 
    {
        name = name_;
        description = description_;
        count = 0;
        sprite = sprite_;
    }
    public ConsumableItem(string name_)
    {
        name = name_;
        description = "";
        count = 0;
    }
    public ConsumableItem()
    {
        name = "";
        description = "";
        count = 0;
    }

    public virtual void OnPickup(GameObject player)
    {
        Debug.Log($"�������� ��������� {name} x{amount}");
        Destroy(gameObject);
    }
}